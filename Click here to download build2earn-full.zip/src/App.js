
import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Build2Earn</h1>
      <p>Create and monetize Fortnite maps!</p>
    </div>
  );
}

export default App;
