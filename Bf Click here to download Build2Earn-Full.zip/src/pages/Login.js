import React from "react";

const Login = () => (
  <div>
    <h2>Login Page</h2>
    <p>(Authentication functionality will go here.)</p>
  </div>
);

export default Login;