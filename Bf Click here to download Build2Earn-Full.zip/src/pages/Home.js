import React from "react";

const Home = () => (
  <div>
    <h1>Welcome to Build2Earn</h1>
    <p>Create and monetize Fortnite maps!</p>
  </div>
);

export default Home;