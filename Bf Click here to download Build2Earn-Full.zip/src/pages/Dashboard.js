import React from "react";

const Dashboard = () => (
  <div>
    <h2>Dashboard</h2>
    <p>(Map views, earnings and Stripe integration will be shown here.)</p>
  </div>
);

export default Dashboard;