# Build2Earn
A React app to help creators monetize Fortnite maps.